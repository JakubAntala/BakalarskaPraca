Táto aplikácia slúži na výber a prihlásenie používateľa na konajúci sa podnikový event v rámci vybraného hotela.
Klienti mozu hodnotit hotely a ich sluzby. Rovnako su pridane funkcie menenia prav uzivatelov a uprava vlastnych udajov v ramci profilu.


