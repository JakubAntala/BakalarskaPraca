package sk.ukf.Projekt.service;

import sk.ukf.Projekt.entity.Hotel;
import sk.ukf.Projekt.entity.HotelReview;

import java.util.List;

public interface HotelReviewService {
    List<HotelReview> findAllByHotel(Hotel hotel);
    void saveReview(HotelReview hotelReview);
    void deleteHotelReviewById(int id);

}
