package sk.ukf.Projekt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sk.ukf.Projekt.entity.Event;
import sk.ukf.Projekt.dao.EventRepository;
import sk.ukf.Projekt.entity.User;
import java.util.List;
import java.util.Optional;

@Service
public class EventServiceImpl implements EventService {

    private final EventRepository eventRepository;

    @Autowired
    public EventServiceImpl(EventRepository eventRepository) {
        this.eventRepository = eventRepository;
    }

    @Override
    public List<Event> getAllEvents() {
        return eventRepository.findAll();
    }

    @Override
    public List<Event> findEventByUser(User user) {
        return eventRepository.findAllByUser(user);
    }

    @Override
    public Optional<Event> getEventById(int id) {
        return eventRepository.findById(id);
    }

    @Override
    public Event saveEvent(Event event) {
        return eventRepository.save(event);
    }

    @Override
    public void deleteEvent(int id) {
        eventRepository.deleteById(id);
    }

    @Override
    public List<Event> searchEventsByName(String name) {
        return eventRepository.findAllByNameContainingIgnoreCase(name);
    }



}