package sk.ukf.Projekt.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import sk.ukf.Projekt.entity.Event;
import sk.ukf.Projekt.entity.EventReservation;
import sk.ukf.Projekt.entity.User;

import java.util.List;
import java.util.Optional;
@Repository
public interface EventReservationRepository extends JpaRepository<EventReservation, Integer> {
    Optional <EventReservation> findByEventAndUser(Event event, User user);

    @Query("SELECT er.user FROM EventReservation er WHERE er.event = :event")
    List<User> findAllUsersByEvent(Event event);

    @Query("SELECT er.event FROM EventReservation er WHERE er.user = :user")
    List<Event> findAllEventsByUser(User user);

    @Query("SELECT er FROM EventReservation er WHERE er.user = :user")
    List<EventReservation> findAllByUser(User user);

    Optional<EventReservation> findTopByEventOrderByCreatedAtDesc(Event event);

}
