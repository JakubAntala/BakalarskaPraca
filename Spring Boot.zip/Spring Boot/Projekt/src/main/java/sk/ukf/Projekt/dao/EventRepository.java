package sk.ukf.Projekt.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import sk.ukf.Projekt.entity.Event;
import sk.ukf.Projekt.entity.User;

import java.util.List;

public interface EventRepository extends JpaRepository<Event, Integer> {
    List<Event> findAllByUser(User user);
    List<Event> findAllByNameContainingIgnoreCase(String name);
}