package sk.ukf.Projekt.service;

import jakarta.transaction.Transactional;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import sk.ukf.Projekt.entity.Event;
import sk.ukf.Projekt.entity.User;

import java.util.List;
import java.util.Optional;

public interface UserService {
    List<User> getAllUsers();

    Optional<User> getUserById(Integer id);
    void updateUserRole(Integer userId, String newRole);
    Optional<User> findByEmail(String email);

    User saveUser(User user);

    void deleteUser(Integer id);



}

