package sk.ukf.Projekt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import sk.ukf.Projekt.entity.Hotel;
import sk.ukf.Projekt.entity.HotelReview;
import sk.ukf.Projekt.entity.User;
import sk.ukf.Projekt.service.HotelReviewService;
import sk.ukf.Projekt.service.HotelService;
import sk.ukf.Projekt.service.UserService;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
public class HotelController {

    private final HotelService hotelService;
    private final HotelReviewService hotelReviewService;
    private final UserService userService;

    @Autowired
    public HotelController(HotelService hotelService, HotelReviewService hotelReviewService, UserService userService, UserService userService1) {
        this.hotelService = hotelService;
        this.hotelReviewService = hotelReviewService;
        this.userService = userService1;
    }

    @GetMapping("/hotel")
    public String viewHotels(Model model) {
        List<Hotel> hotelList = hotelService.getAllHotels();
        model.addAttribute("hotels", hotelList);
        return "hotel/index";
    }

    @GetMapping("/hotel/{id}")
    public String getHotelDetail(@PathVariable int id, Model model) {
        Hotel hotel = hotelService.getHotelById(id)
                .orElseThrow(() -> new RuntimeException("Hotel not found"));
        List<HotelReview> hotelReviews = hotelReviewService.findAllByHotel(hotel);
        model.addAttribute("hotel", hotel);
        model.addAttribute("hotelReviews", hotelReviews != null ? hotelReviews : new ArrayList<>());
        return "hotel/hotel-detail";
    }

    @GetMapping("/hotel/review/add-review/{hotelId}")
    public String showAddReviewForm(@PathVariable("hotelId") int hotelId, Model model) {

        Hotel hotel = hotelService.getHotelById(hotelId)
                .orElseThrow(() -> new RuntimeException("Hotel not found"));

        HotelReview review = new HotelReview();
        review.setHotel(hotel);

        model.addAttribute("review", review);
        model.addAttribute("hotel", hotel);
        return "hotel/add-review";
    }


    @PostMapping("/hotel/review/save-review")
    public String saveHotelReview(@ModelAttribute("review") HotelReview review, Principal principal) {
        User currentUser = userService.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("Používateľ nenájdený"));

        review.setUser(currentUser);
        review.setDate(new Date());

        hotelReviewService.saveReview(review);

        return "redirect:/hotel/" + review.getHotel().getId();
    }
}
