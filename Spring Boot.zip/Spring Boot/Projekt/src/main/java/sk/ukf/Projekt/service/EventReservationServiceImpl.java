package sk.ukf.Projekt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sk.ukf.Projekt.dao.EventRepository;
import sk.ukf.Projekt.dao.EventReservationRepository;
import sk.ukf.Projekt.entity.Event;
import sk.ukf.Projekt.entity.EventReservation;
import sk.ukf.Projekt.entity.User;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class EventReservationServiceImpl implements EventReservationService {

    @Autowired
    private EventReservationRepository eventReservationRepository;
    @Autowired
    private EventRepository eventRepository;

    @Override
    public EventReservation saveEventReservation(EventReservation eventReservation) {
        return eventReservationRepository.save(eventReservation);
    }

    @Override
    public void deleteEventReservation(EventReservation eventReservation) {
        eventReservationRepository.delete(eventReservation);
    }

    @Override
    public Optional<EventReservation> findbyEventAndUser(Event event, User user) {
        return eventReservationRepository.findByEventAndUser(event, user);
    }

    @Override
    public List<User> findAllUsersByEvent(Event event) {
        return eventReservationRepository.findAllUsersByEvent(event);
    }

    @Override
    public List<Event> findAllEventsByUser(User user) {
        return eventReservationRepository.findAllEventsByUser(user);
    }

    @Override
    public int countUsersInEvent(Event event) {
        return findAllUsersByEvent(event).size();
    }
    @Override
    public List<EventReservation> findReservationsByUser(User user) {
        return eventReservationRepository.findAllByUser(user);
    }

    @Override
    public void reserveEvent(int eventId, User user) {
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new RuntimeException("Udalosť nebola nájdená"));

        Optional<EventReservation> lastReservation = eventReservationRepository
                .findTopByEventOrderByCreatedAtDesc(event);

        EventReservation reservation = new EventReservation();
        reservation.setEvent(event);
        reservation.setUser(user);

        if (lastReservation.isPresent()) {
            reservation.setStartTime(lastReservation.get().getStartTime());
            reservation.setEndTime(lastReservation.get().getEndTime());
        } else {
            reservation.setStartTime(LocalDateTime.now());
            reservation.setEndTime(LocalDateTime.now().plusHours(2));
        }

        reservation.setReservationDate(LocalDateTime.now());
        reservation.setCreatedAt(LocalDateTime.now());
        reservation.setUpdatedAt(LocalDateTime.now());

        eventReservationRepository.save(reservation);
    }

}
