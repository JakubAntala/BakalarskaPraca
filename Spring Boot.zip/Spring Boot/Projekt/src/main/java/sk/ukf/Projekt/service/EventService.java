package sk.ukf.Projekt.service;

import sk.ukf.Projekt.entity.Event;
import sk.ukf.Projekt.entity.User;

import java.util.List;
import java.util.Optional;

public interface EventService {
    List<Event> getAllEvents();
    Optional<Event> getEventById(int id);
    List<Event> findEventByUser(User user);

    Event saveEvent(Event event);

    void deleteEvent(int id);
    List<Event> searchEventsByName(String name);
}
