package sk.ukf.Projekt.controller;


import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.BindingResult;
import sk.ukf.Projekt.config.CustomUserDetails;
import sk.ukf.Projekt.entity.User;

import sk.ukf.Projekt.service.UserService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AuthController {

    private final UserService userService;
    private final PasswordEncoder passwordEncoder;

    public AuthController(UserService userService, PasswordEncoder passwordEncoder) {
        this.userService = userService;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/login")
    public String showLoginPage() {
        return "auth/login";
    }

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new User());
        return "auth/register";
    }
    @PostMapping("/register")
    public String registerUser(@ModelAttribute("user") User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        user.setRole("guest");

        userService.saveUser(user);

        return "redirect:/login?register";
    }

    @GetMapping("/user/edit-profile")
    public String showEditProfileForm(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();

        User currentUser = userService.findByEmail(userDetails.getUsername())
                .orElseThrow(() -> new RuntimeException("Používateľ nenájdený"));

        model.addAttribute("user", currentUser);
        return "auth/edit-profile";
    }


    @PostMapping("/user/update-profile")
    public String updateUserProfile(@ModelAttribute("user") User updatedUser, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("user", updatedUser);
            return "auth/edit-profile";
        }

        User existingUser = userService.getUserById(updatedUser.getId())
                .orElseThrow(() -> new RuntimeException("Používateľ nenájdený"));

        if (updatedUser.getBorn() == null) {
            updatedUser.setBorn(existingUser.getBorn());
        }
        if (updatedUser.getFirstName() == null) {
            updatedUser.setFirstName(existingUser.getFirstName());
        }
        if (updatedUser.getLastName() == null) {
            updatedUser.setLastName(existingUser.getLastName());
        }
        if (updatedUser.getEmail() == null) {
            updatedUser.setEmail(existingUser.getEmail());
        }
        if (updatedUser.getPhone() == null) {
            updatedUser.setPhone(existingUser.getPhone());
        }
        if (updatedUser.getGender() == null) {
            updatedUser.setGender(existingUser.getGender());
        }

        existingUser.setRole(existingUser.getRole());

        if (updatedUser.getPassword() != null && !updatedUser.getPassword().isEmpty()) {
            updatedUser.setPassword(passwordEncoder.encode(updatedUser.getPassword()));
        } else {
            updatedUser.setPassword(existingUser.getPassword());
        }

        userService.saveUser(updatedUser);



        return "redirect:/";
    }
}
