package sk.ukf.Projekt.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sk.ukf.Projekt.dao.HotelReviewRepository;
import sk.ukf.Projekt.entity.Hotel;
import sk.ukf.Projekt.entity.HotelReview;
import sk.ukf.Projekt.service.HotelReviewService;

import java.util.List;

@Service
public class HotelReviewServiceImpl implements HotelReviewService {

    private final HotelReviewRepository hotelReviewRepository;

    @Autowired
    public HotelReviewServiceImpl(HotelReviewRepository hotelReviewRepository) {
        this.hotelReviewRepository = hotelReviewRepository;
    }

    @Override
    public List<HotelReview> findAllByHotel(Hotel hotel) {
        return hotelReviewRepository.findByHotel(hotel);
    }

    @Override
    public void saveReview(HotelReview review) {
        if (review.getHotel() == null) {
            throw new IllegalArgumentException("Hotel nesmie byť null.");
        }
        if (review.getRating() < 0 || review.getRating() > 5) {
            throw new IllegalArgumentException("Hodnotenie musí byť medzi 0 a 5.");
        }
        hotelReviewRepository.save(review);
    }



    @Override
    public void deleteHotelReviewById(int id) {
        hotelReviewRepository.deleteById(id);
    }
}
