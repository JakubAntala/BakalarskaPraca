package sk.ukf.Projekt.service;

import sk.ukf.Projekt.entity.Hotel;

import java.util.List;
import java.util.Optional;

public interface HotelService {
    List<Hotel> getAllHotels();
    Optional<Hotel> getHotelById(int id);
    Hotel saveHotel(Hotel hotel);
    void deleteHotel(int id);
}
