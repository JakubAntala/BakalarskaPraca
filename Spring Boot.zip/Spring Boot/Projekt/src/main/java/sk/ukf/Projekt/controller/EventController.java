package sk.ukf.Projekt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import sk.ukf.Projekt.entity.Event;
import sk.ukf.Projekt.entity.EventReservation;
import sk.ukf.Projekt.entity.User;
import sk.ukf.Projekt.service.EventReservationService;
import sk.ukf.Projekt.service.EventService;
import sk.ukf.Projekt.service.HotelService;
import sk.ukf.Projekt.service.UserService;

import java.security.Principal;
import java.util.List;

@Controller
public class EventController {

    private  EventService eventService;
    private  UserService userService;
    private  EventReservationService eventReservationService;
    private HotelService hotelService;

    @Autowired
    public EventController(EventService eventService, UserService userService,EventReservationService eventReservationService, HotelService hotelService) {
        this.eventService = eventService;
        this.userService = userService;
        this.eventReservationService = eventReservationService;
        this.hotelService = hotelService;


    }

    @GetMapping("/")
    public String viewHomePage(Model model) {
        List<Event> eventList = eventService.getAllEvents();
        model.addAttribute("events", eventList);
        return "index";
    }

    @GetMapping("/event/{id}")
    public String viewEventDetail(@PathVariable("id") int id, Model model, Principal principal) {
        Event event = eventService.getEventById(id)
                .orElseThrow(() -> new RuntimeException("Event not found"));

        boolean isAuthenticated = principal != null;
        boolean isOwner = false;
        boolean isReserved = false;
        boolean isAdmin = false;

        if (isAuthenticated) {
            User user = userService.findByEmail(principal.getName())
                    .orElseThrow(() -> new RuntimeException("User not found"));
            isOwner = event.getUser() != null && event.getUser().getId() == user.getId();
            isReserved = eventReservationService.findbyEventAndUser(event, user).isPresent();
            isAdmin = user.getRole().equalsIgnoreCase("admin");
        }

        model.addAttribute("event", event);
        model.addAttribute("isAuthenticated", isAuthenticated);
        model.addAttribute("isOwner", isOwner);
        model.addAttribute("isReserved", isReserved);
        model.addAttribute("isAdmin", isAdmin);

        return "event/event-detail";
    }


    @GetMapping({"/guest/my-events", "/staff/my-events"})

    public String viewUserEvents(Model model, Principal principal) {

        User user = userService.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        List<EventReservation> reservations = eventReservationService.findReservationsByUser(user);
        model.addAttribute("reservations", reservations);

        return "event/my-events";
    }

    @GetMapping("/admin/user-list")
    public String showUserList(Model model) {
        List<User> users = userService.getAllUsers();
        model.addAttribute("users", users);
        return "auth/user-list";
    }
    @PostMapping("/update-role")
    public String updateUserRole(@RequestParam("userId") Integer userId, @RequestParam("newRole") String newRole) {
        userService.updateUserRole(userId, newRole);
        return "redirect:/admin/user-list";
    }


    @GetMapping({"/admin/add-event", "/staff/add-event"})
    public String showAddEventForm(Model model) {
        model.addAttribute("event", new Event());
        model.addAttribute("hotels", hotelService.getAllHotels());
        return "event/add-event";
    }



    @PostMapping("/save")
    public String saveEvent(@ModelAttribute Event event, Principal principal) {
        User user = userService.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("Používateľ nebol nájdený"));

        event.setUser(user);


        if (event.getHotel() == null) {
            throw new RuntimeException("Hotel nie je vybraný");
        }

        eventService.saveEvent(event);
        return "redirect:/";
    }

    @GetMapping({"/staff/my-ownevents", "admin/my-ownevents"})
    public String viewMyEvents(Model model, Principal principal) {
        User user = userService.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        List<Event> userEvents = eventService.findEventByUser(user);

        model.addAttribute("events", userEvents);

        return "event/my-ownevents";
    }

    @GetMapping("/search")
    public String searchEvents(@RequestParam("query") String query, Model model) {
        List<Event> events;
        if (query == null || query.trim().isEmpty()) {
            events = eventService.getAllEvents();
        } else {
            events = eventService.searchEventsByName(query);
        }
        model.addAttribute("events", events);
        return "index";
    }

    @PostMapping("/event/delete/{id}")
    public String deleteEvent(@PathVariable int id, Principal principal) {
        Event event = eventService.getEventById(id)
                .orElseThrow(() -> new RuntimeException("Event not found"));

        User currentUser = userService.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!event.getUser().equals(currentUser) && !currentUser.getRole().equalsIgnoreCase("admin")) {
            throw new RuntimeException("You do not have permission to delete this event");
        }

        eventService.deleteEvent(id);
        return "redirect:/";
    }

    @GetMapping("/event/edit/{id}")
    public String showEditEventForm(@PathVariable int id, Model model, Principal principal) {
        Event event = eventService.getEventById(id)
                .orElseThrow(() -> new RuntimeException("Event not found"));

        User currentUser = userService.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!event.getUser().equals(currentUser) && !currentUser.getRole().equalsIgnoreCase("admin")) {
            throw new RuntimeException("Nemáte povolenie upravovať tento event");
        }

        model.addAttribute("hotels", hotelService.getAllHotels());
        model.addAttribute("event", event);
        return "event/add-event";
    }

    @PostMapping("/event/reserve/{eventId}")
    public String reserveEvent(@PathVariable int eventId, Principal principal) {
        User user = userService.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("Používateľ nebol nájdený"));

        eventReservationService.reserveEvent(eventId, user);

        return "redirect:/event/" + eventId;
    }

    @PostMapping("/event/cancel-reservation/{eventId}")
    public String cancelReservation(@PathVariable int eventId, Principal principal) {
        User user = userService.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("Používateľ nebol nájdený"));

        Event event = eventService.getEventById(eventId)
                .orElseThrow(() -> new RuntimeException("Udalosť nebola nájdená"));

        EventReservation reservation = eventReservationService.findbyEventAndUser(event, user)
                .orElseThrow(() -> new RuntimeException("Rezervácia nebola nájdená"));

        eventReservationService.deleteEventReservation(reservation);

        return "redirect:/event/" + eventId;
    }


}
