package sk.ukf.Projekt.service;

import sk.ukf.Projekt.entity.User;
import sk.ukf.Projekt.entity.EventReservation;
import sk.ukf.Projekt.entity.Event;

import java.util.List;
import java.util.Optional;
public interface EventReservationService {
    EventReservation saveEventReservation(EventReservation eventReservation);
    void deleteEventReservation(EventReservation eventReservation);
    Optional<EventReservation> findbyEventAndUser(Event event, User user);
    List<User> findAllUsersByEvent(Event event);
    List<Event> findAllEventsByUser(User user);
    int countUsersInEvent(Event event);
    List<EventReservation> findReservationsByUser(User user);
    void reserveEvent(int eventId, User user);

}
